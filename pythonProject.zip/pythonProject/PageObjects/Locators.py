#Login Page elements
txt_loginUserName="name:username"
txt_loginPassword="name:password"
txt_loginButton="xpath://button[@type='submit']"

#Add New User Page Elements
adminLink="xpath://a[@class='oxd-main-menu-item active']"
addButton="xpath://button[normalize-space()='Add']"
userRoleDropdown="xpath:/html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]"
statusDropDown="xpath:/html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/form[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]"
txt_employeeName="xpath://input[@placeholder='Type for hints...']"
txt_userNAme="xpath://div[@class='oxd-form-row']//div[@class='oxd-grid-2 orangehrm-full-width-grid']//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@class='oxd-input oxd-input--active']"
txt_pwd="xpath://div[@class='oxd-grid-item oxd-grid-item--gutters user-password-cell']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@type='password']"
txt_confirmPwd="xpath://div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@type='password']"
saveButton="xpath://button[@type='submit']"
avatarIconDropDown="xpath://i[@class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']"
logOut="xpath://a[normalize-space()='Logout']"